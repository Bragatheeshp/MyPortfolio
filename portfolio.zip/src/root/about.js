import React from 'react'
import Navbar from '../componets/Navbar'
import Heroimg2 from '../componets/Heroimg2'
import Footer from '../componets/footer'
import Aboutcontant from '../componets/aboutcontant'


const About = () => {
  return (
    <div>
      <Navbar/>
      < Heroimg2 heading="ABOUT" text=" I'm Front-End Developer" />
      <Aboutcontant/>
<Footer/>
    </div>
  )
}

export default About