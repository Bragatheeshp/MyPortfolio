import React from 'react'
import Navbar from '../componets/Navbar'
import Heroimg from '../componets/Heroimg'
import Footer from '../componets/footer'


const Home = () => {
  return (
    <div>
      <Navbar/>
      <Heroimg/>
      <Footer/>
    </div>
  )
}

export default Home