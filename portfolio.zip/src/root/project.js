import React from 'react'
import Heroimg2 from '../componets/Heroimg2'
import Navbar from '../componets/Navbar'
import Footer from '../componets/footer'
import Work from '../componets/Work'



const Project = () => {
  return (
    <div>
      <Navbar/>
      <Heroimg2 heading="PROJECTS" text="Some of the projects using HTML,CSS,JAVASCRIPT" />
      <Work/>
  
   <Footer/>
    </div>
    
  )
}

export default Project