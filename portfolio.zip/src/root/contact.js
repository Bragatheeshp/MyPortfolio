import React from 'react'
import Navbar from '../componets/Navbar'
import Heroimg2 from '../componets/Heroimg2'
import Footer from '../componets/footer'
import Form from '../componets/form'



const Contact = () => {
  return (
    <div>
      <Navbar/>
      <Heroimg2 heading=".CONTACT" text=" Lets have a connect"/>
      <Form/>
      <Footer/>

    </div>
  )
}

export default Contact