import "../componets/aboutcontant.css"
import React from 'react'
import { Link } from "react-router-dom"
import top from '../gallery/1.jpg'
import bottom from '../gallery/3.jpg'


const Aboutcontant = () => {
  return (
    <div className="about">
        <div className="left">
            <h1>ABOUT ME</h1>
            <p>I'm looking for an entry-level position to kick start my career in Front-End Developer</p>
        <Link to="/contact">
            <button className="btn">CONTACT</button>
        </Link>
        </div>
        <div className="right">
            <div className="img-container">
                <div className="top">
<img src={top} alt="img" className="img"/>
                </div>
                <div className="bottom">
<img src={bottom} alt="img" className="img"/>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Aboutcontant