import pro1 from '../gallery/a.png'
import pro2 from '../gallery/b.png'
import pro3 from '../gallery/c.png'

const ProjectData=[
    {
        imgsrc: pro1,
        title:"Tic-Tac-Toe",
        text:"It is quite easy to develop with some simple validations and error checks. Player-1 starts playing the game and both the players make their moves in consecutive turns. The player who makes a straight 3-block chain wins the game. This game is built on the front-end using simple logic and validation checks only.",
        view:"https://github.com/Bragatheeshp/TicTacToe.git",
    },
    {
        imgsrc: pro2,
        title:"Analog-Clock",
        text:"I will create three files (HTML file, a CSS file, and JavaScript File), I also have an image of the clock that will be used in the background, and on top of that, we will make an hour, minute, and second hand (using HTML and CSS). These hands will rotate as per the system time.",
        view:"https://github.com/Bragatheeshp/analogClock.git",
    },
    {
        imgsrc: pro3,
        title:"Digital-Clock",
        text:"Clocks are useful element for any UI if used in a proper way. Clocks can be used in sites where time is the main concern like some booking sites or some app showing arriving times of train, buses, flights, etc. Clock is basically of two types, Analog and Digital. We will be looking at making a digital one.",
        view:"https://github.com/Bragatheeshp/digitalclock.git",
    }
]
export default ProjectData;