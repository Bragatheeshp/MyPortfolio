import "./heroimf.css";
import React from 'react'
import intro from "../gallery/intro.jpg"
import { Link } from "react-router-dom";

const Heroimg = () => {
  return (
    <div className="hero">
        <div className="mass">
<img className="intro" src={intro} alt='introImg'/>
        </div>
        <div className="content"><p>
            HAI,THIS IS BRAGATHEESH</p>
            <h1>FRONT-END DEVELOPER</h1>
            
                <Link to="/project" className="btn">PROJECT
            </Link>
            <Link to="/contact" className="btn btn-light">
            CONTACT</Link>
          </div>
           
    </div>
  )
}

export default Heroimg