import "./Workcard.css"
import React from 'react'
import ProjectData from "./Worksdata"
import WorkCard from "./WorkCard"


const Work = () => {
  return (
    <div className="work-contant">
        <h1 className="projectheading">Projects</h1>
    <div className="project-contant">
        {ProjectData.map((val,ind)=>{
            return(
                <WorkCard 
                key={ind}
                imgsrc={val.imgsrc}
                title={val.title}
                text={val.text}
                view={val.view}
                /> 
            )
        })}
    </div>
    </div>
  )
}

export default Work