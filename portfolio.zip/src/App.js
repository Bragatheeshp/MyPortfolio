import logo from './logo.svg';
import './App.css';
import Home from './root/home';
import About from './root/about';
import Project from './root/project';
import Contact from './root/contact';
import {Routes,Route} from 'react-router-dom';


function App() {
  return (
   <>
   <Routes>
    <Route path="/" element= {<Home/>} />
    <Route path='/about' element={<About/>}/>
    <Route path='/project' element={<Project/>}/>
    <Route path='/contact' element={<Contact/>}/>
   </Routes>
   </>
  );
}

export default App;
